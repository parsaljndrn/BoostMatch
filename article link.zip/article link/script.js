const API_URL = 'http://localhost:5000/api/extract';

document.getElementById('extractForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const fbUrl = document.getElementById('fbUrl').value;
    const extractBtn = document.getElementById('extractBtn');
    const btnText = extractBtn.querySelector('.btn-text');
    const loader = extractBtn.querySelector('.loader');
    const statusSection = document.getElementById('statusSection');
    const statusMessage = document.getElementById('statusMessage');
    const resultsSection = document.getElementById('resultsSection');
    
    // Disable button and show loader
    extractBtn.disabled = true;
    btnText.textContent = 'Extracting...';
    loader.style.display = 'inline-block';
    
    // Show loading status
    statusSection.style.display = 'block';
    statusMessage.className = 'status-message loading';
    statusMessage.textContent = '🔍 Analyzing Facebook post and extracting article link...';
    
    // Hide previous results
    resultsSection.style.display = 'none';
    
    try {
        const response = await fetch(API_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ facebook_url: fbUrl })
        });
        
        const data = await response.json();
        
        if (response.ok && data.success) {
            // Show success status
            statusMessage.className = 'status-message success';
            statusMessage.textContent = '✅ Article successfully extracted!';
            
            // Display results
            displayArticle(data.article);
            resultsSection.style.display = 'block';
            
            // Hide status after 3 seconds
            setTimeout(() => {
                statusSection.style.display = 'none';
            }, 3000);
        } else {
            // Show error
            statusMessage.className = 'status-message error';
            statusMessage.textContent = `❌ Error: ${data.error || 'Failed to extract article'}`;
        }
    } catch (error) {
        // Show error
        statusMessage.className = 'status-message error';
        statusMessage.textContent = `❌ Error: ${error.message || 'Network error. Make sure the Python server is running.'}`;
    } finally {
        // Re-enable button
        extractBtn.disabled = false;
        btnText.textContent = 'Extract Article';
        loader.style.display = 'none';
    }
});

function displayArticle(article) {
    // Title
    document.getElementById('articleTitle').textContent = article.title || 'Untitled Article';
    
    // Original link
    const articleLink = document.getElementById('articleLink');
    articleLink.href = article.url || '#';
    
    // Meta information
    document.getElementById('articleSource').textContent = article.source || 'Unknown Source';
    document.getElementById('articleDate').textContent = article.publish_date || '';
    
    // Image
    const imageContainer = document.getElementById('articleImageContainer');
    const articleImage = document.getElementById('articleImage');
    if (article.image) {
        articleImage.src = article.image;
        articleImage.alt = article.title || 'Article image';
        imageContainer.style.display = 'block';
    } else {
        imageContainer.style.display = 'none';
    }
    
    // Description
    const descriptionEl = document.getElementById('articleDescription');
    if (article.description) {
        descriptionEl.textContent = article.description;
        descriptionEl.style.display = 'block';
    } else {
        descriptionEl.style.display = 'none';
    }
    
    // Content
    const contentEl = document.getElementById('articleContent');
    if (article.content) {
        // Convert plain text to paragraphs
        const paragraphs = article.content.split('\n\n').filter(p => p.trim());
        contentEl.innerHTML = paragraphs.map(p => `<p>${p}</p>`).join('');
    } else {
        contentEl.innerHTML = '<p>No content available.</p>';
    }
    
    // Store article data for copy/download functions
    window.currentArticle = article;
}

function copyToClipboard() {
    if (!window.currentArticle) return;
    
    const article = window.currentArticle;
    const text = `${article.title}\n\n${article.description || ''}\n\n${article.content || ''}\n\nSource: ${article.url}`;
    
    navigator.clipboard.writeText(text).then(() => {
        alert('✅ Article copied to clipboard!');
    }).catch(err => {
        alert('❌ Failed to copy to clipboard');
        console.error(err);
    });
}

function downloadArticle() {
    if (!window.currentArticle) return;
    
    const article = window.currentArticle;
    const content = `${article.title}\n${'='.repeat(article.title.length)}\n\n${article.description || ''}\n\n${article.content || ''}\n\nSource: ${article.url}\nExtracted on: ${new Date().toLocaleString()}`;
    
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${article.title.substring(0, 50).replace(/[^a-z0-9]/gi, '_')}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}
