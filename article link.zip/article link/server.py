"""
Facebook Article Extractor Backend
This Flask server extracts article links from Facebook posts and fetches the article content.
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
import requests
from bs4 import BeautifulSoup
import re
from urllib.parse import urlparse, parse_qs, unquote
from datetime import datetime
import json

app = Flask(__name__)
CORS(app)  # Enable CORS for frontend requests

# User agent to mimic a browser
HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
    'Accept-Encoding': 'gzip, deflate',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1'
}

def extract_article_url_from_facebook(fb_url):
    """
    Extract the article URL from a Facebook post.
    Facebook often wraps external links in their redirect system.
    """
    try:
        # Try to extract URL from Facebook's redirect parameter
        parsed_url = urlparse(fb_url)
        
        # Method 1: Check if it's already a direct link in the URL parameters
        if 'l.php' in fb_url or 'l.facebook.com' in fb_url:
            params = parse_qs(parsed_url.query)
            if 'u' in params:
                return unquote(params['u'][0])
        
        # Method 2: Fetch the Facebook page and extract links
        response = requests.get(fb_url, headers=HEADERS, timeout=10)
        response.raise_for_status()
        
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # Look for external links in the page
        # Facebook often includes article links in specific meta tags or link elements
        
        # Check meta tags
        og_url = soup.find('meta', property='og:url')
        if og_url and og_url.get('content'):
            url = og_url.get('content')
            if not 'facebook.com' in url:
                return url
        
        # Check all links
        links = soup.find_all('a', href=True)
        for link in links:
            href = link.get('href')
            
            # Skip Facebook internal links
            if any(domain in href for domain in ['facebook.com', 'fb.com', 'fb.me']):
                # Check if it's a redirect link
                if 'l.php' in href or '/l.php' in href:
                    parsed = urlparse(href)
                    params = parse_qs(parsed.query)
                    if 'u' in params:
                        external_url = unquote(params['u'][0])
                        if is_likely_article_url(external_url):
                            return external_url
                continue
            
            # Check if it looks like an article URL
            if is_likely_article_url(href):
                return href
        
        return None
        
    except Exception as e:
        print(f"Error extracting URL from Facebook: {str(e)}")
        return None

def is_likely_article_url(url):
    """
    Check if a URL is likely to be a news article.
    """
    # Common news/article domains patterns
    news_indicators = [
        'news', 'article', 'story', 'post', 'blog', 
        '.com/', '.org/', '.net/', '.co/',
        '/202', '/201'  # Year in URL (common in news articles)
    ]
    
    # Exclude social media and common non-article sites
    exclude = ['facebook.com', 'fb.com', 'twitter.com', 'instagram.com', 'youtube.com']
    
    url_lower = url.lower()
    
    # Check if it's not an excluded domain
    if any(domain in url_lower for domain in exclude):
        return False
    
    # Check if it has news indicators
    if any(indicator in url_lower for indicator in news_indicators):
        return True
    
    # Check if it's a valid http/https URL
    return url.startswith('http://') or url.startswith('https://')

def extract_article_content(url):
    """
    Extract article content from a URL using web scraping.
    """
    try:
        response = requests.get(url, headers=HEADERS, timeout=15)
        response.raise_for_status()
        
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # Extract title
        title = None
        title_tag = soup.find('meta', property='og:title')
        if title_tag:
            title = title_tag.get('content')
        if not title:
            title_tag = soup.find('title')
            if title_tag:
                title = title_tag.get_text()
        if not title:
            h1_tag = soup.find('h1')
            if h1_tag:
                title = h1_tag.get_text()
        
        # Extract description
        description = None
        desc_tag = soup.find('meta', property='og:description')
        if desc_tag:
            description = desc_tag.get('content')
        if not description:
            desc_tag = soup.find('meta', attrs={'name': 'description'})
            if desc_tag:
                description = desc_tag.get('content')
        
        # Extract image
        image = None
        img_tag = soup.find('meta', property='og:image')
        if img_tag:
            image = img_tag.get('content')
        
        # Extract publish date
        publish_date = None
        date_tag = soup.find('meta', property='article:published_time')
        if date_tag:
            publish_date = date_tag.get('content')
        
        # Extract source/site name
        source = None
        site_tag = soup.find('meta', property='og:site_name')
        if site_tag:
            source = site_tag.get('content')
        if not source:
            source = urlparse(url).netloc
        
        # Extract main content
        content = extract_main_content(soup)
        
        return {
            'title': title,
            'description': description,
            'content': content,
            'image': image,
            'url': url,
            'source': source,
            'publish_date': publish_date
        }
        
    except Exception as e:
        print(f"Error extracting article content: {str(e)}")
        raise

def extract_main_content(soup):
    """
    Extract the main article text content.
    """
    # Remove script and style elements
    for script in soup(['script', 'style', 'nav', 'header', 'footer', 'aside']):
        script.decompose()
    
    # Try common article container classes/ids
    article_containers = [
        soup.find('article'),
        soup.find('div', class_=re.compile(r'article|content|post|entry|story', re.I)),
        soup.find('div', id=re.compile(r'article|content|post|entry|story', re.I)),
        soup.find('main'),
    ]
    
    content_text = []
    
    for container in article_containers:
        if container:
            # Extract paragraphs
            paragraphs = container.find_all('p')
            for p in paragraphs:
                text = p.get_text().strip()
                if len(text) > 50:  # Only include substantial paragraphs
                    content_text.append(text)
            
            if content_text:
                break
    
    # If no content found in containers, try all paragraphs
    if not content_text:
        paragraphs = soup.find_all('p')
        for p in paragraphs:
            text = p.get_text().strip()
            if len(text) > 50:
                content_text.append(text)
    
    return '\n\n'.join(content_text)

@app.route('/api/extract', methods=['POST'])
def extract_article():
    """
    Main API endpoint to extract article from Facebook post.
    """
    try:
        data = request.get_json()
        fb_url = data.get('facebook_url')
        
        if not fb_url:
            return jsonify({
                'success': False,
                'error': 'Facebook URL is required'
            }), 400
        
        # Step 1: Extract article URL from Facebook post
        print(f"Extracting article URL from: {fb_url}")
        article_url = extract_article_url_from_facebook(fb_url)
        
        if not article_url:
            return jsonify({
                'success': False,
                'error': 'Could not find article link in the Facebook post. The post might be private or doesn\'t contain an external link.'
            }), 404
        
        print(f"Found article URL: {article_url}")
        
        # Step 2: Extract article content
        article_data = extract_article_content(article_url)
        
        return jsonify({
            'success': True,
            'article': article_data
        })
        
    except requests.exceptions.RequestException as e:
        return jsonify({
            'success': False,
            'error': f'Network error: {str(e)}'
        }), 500
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'An error occurred: {str(e)}'
        }), 500

@app.route('/api/health', methods=['GET'])
def health_check():
    """
    Health check endpoint.
    """
    return jsonify({
        'status': 'ok',
        'message': 'Facebook Article Extractor API is running'
    })

if __name__ == '__main__':
    print("=" * 60)
    print("Facebook Article Extractor Backend Server")
    print("=" * 60)
    print("Server starting on http://localhost:5000")
    print("Open index.html in your browser to use the application")
    print("=" * 60)
    app.run(debug=True, port=5000)
