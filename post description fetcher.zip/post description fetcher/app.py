"""
Facebook Post Description Extractor
Simple Flask backend to extract descriptions from Facebook posts
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
import yt_dlp

app = Flask(__name__)
CORS(app)


def extract_facebook_description(url):
    """
    Extract description from Facebook post using yt-dlp
    """
    try:
        # Configure yt-dlp
        ydl_opts = {
            'quiet': True,
            'no_warnings': True,
            'skip_download': True,
            'extract_flat': False,
        }
        
        print(f"[INFO] Extracting from: {url}")
        
        # Extract info
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=False)
            
            # Get description
            description = info.get('description', '')
            
            if not description:
                return None, "No description found for this post"
            
            print(f"[SUCCESS] Extracted {len(description)} characters")
            return description, None
            
    except Exception as e:
        error_msg = str(e)
        print(f"[ERROR] {error_msg}")
        
        # Provide helpful error messages
        if 'private' in error_msg.lower():
            return None, "This post is private. Please use a public post URL."
        elif 'not found' in error_msg.lower() or '404' in error_msg:
            return None, "Post not found. The post may have been deleted."
        elif 'login' in error_msg.lower():
            return None, "This post requires login. Please use a public post."
        else:
            return None, f"Failed to extract description: {error_msg}"


@app.route('/extract', methods=['POST'])
def extract():
    """
    API endpoint to extract Facebook post description
    
    Request: {"url": "https://www.facebook.com/..."}
    Response: {"success": true, "description": "..."}
    """
    try:
        data = request.get_json()
        
        if not data or 'url' not in data:
            return jsonify({
                'success': False,
                'error': 'URL is required'
            }), 400
        
        url = data['url']
        
        # Validate URL
        if 'facebook.com' not in url.lower() and 'fb.watch' not in url.lower():
            return jsonify({
                'success': False,
                'error': 'Please provide a valid Facebook URL'
            }), 400
        
        print("=" * 60)
        print(f"Processing: {url}")
        print("=" * 60)
        
        # Extract description
        description, error = extract_facebook_description(url)
        
        if error:
            return jsonify({
                'success': False,
                'error': error
            }), 400
        
        print("=" * 60)
        print("Success!")
        print("=" * 60)
        
        return jsonify({
            'success': True,
            'description': description
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/health', methods=['GET'])
def health():
    """Health check endpoint"""
    return jsonify({'status': 'ok'})


if __name__ == '__main__':
    print("=" * 60)
    print("Facebook Post Description Extractor")
    print("=" * 60)
    print("Server: http://localhost:5000")
    print("Endpoint: POST /extract")
    print("")
    print("Install: pip install flask flask-cors yt-dlp")
    print("=" * 60)
    print("")
    
    app.run(debug=True, host='0.0.0.0', port=5000)
